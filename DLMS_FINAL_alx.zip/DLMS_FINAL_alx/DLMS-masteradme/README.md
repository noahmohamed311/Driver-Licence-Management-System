# Driver Licence Management System

This is a second year project for OOP and Database courses. The task was to make an application with a GUI and database
which can be used in driver licence issuing system. It is implemented in Java and MySQL.
