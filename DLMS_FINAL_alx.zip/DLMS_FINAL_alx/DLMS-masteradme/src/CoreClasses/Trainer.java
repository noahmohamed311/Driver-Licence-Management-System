package CoreClasses;

public class Trainer extends Person{
}
