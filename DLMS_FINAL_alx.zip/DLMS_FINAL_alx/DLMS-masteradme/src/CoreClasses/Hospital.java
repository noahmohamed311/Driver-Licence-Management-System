package CoreClasses;

public class Hospital extends Organization {

}
