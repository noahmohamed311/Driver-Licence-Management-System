package CoreClasses;

public class School extends Organization{
}
