package CoreClasses;

public class Driver extends Person{
}
